python mainMiccaiSegPlusClass.py --save-dir=save_MiccaiSegPlusClass --batchSize 2 --lr 0.005 --epochs 10 --saveTest True --resume save_MiccaiRecon/checkpoint_1.tar| tee -a log_MiccaiSegPlusClass
