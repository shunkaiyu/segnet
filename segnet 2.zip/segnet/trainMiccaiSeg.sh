python mainMiccaiSeg.py --save-dir=save_MiccaiSeg --batchSize 1 --lr 0.005 --epochs 5 --saveTest True | tee -a log_MiccaiSeg
