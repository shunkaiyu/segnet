python mainMiccaiRecon.py --save-dir=save_MiccaiRecon --batchSize 64 --lr 0.01 --epochs 2 --imageSize 256 | tee -a log_MiccaiRecon
