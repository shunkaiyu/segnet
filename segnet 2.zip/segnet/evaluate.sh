python evaulate.py --save-dir=/media/salman/DATA/miccaiSegEval --saveTest True --model /media/salman/DATA/miccaiSegResults7/checkpoint_99.tar |& tee -a log_MiccaiSegEval
